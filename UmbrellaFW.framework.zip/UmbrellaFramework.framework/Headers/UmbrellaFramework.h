//
//  UmbrellaFramework.h
//  UmbrellaFramework
//
//  Created by MAC-OBS-20 on 24/04/22.
//

#import <Foundation/Foundation.h>

//! Project version number for UmbrellaFramework.
FOUNDATION_EXPORT double UmbrellaFrameworkVersionNumber;

//! Project version string for UmbrellaFramework.
FOUNDATION_EXPORT const unsigned char UmbrellaFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UmbrellaFramework/PublicHeader.h>


