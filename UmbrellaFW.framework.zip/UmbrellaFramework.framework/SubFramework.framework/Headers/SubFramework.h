//
//  SubFramework.h
//  SubFramework
//
//  Created by MAC-OBS-20 on 20/04/22.
//

#import <Foundation/Foundation.h>

//! Project version number for SubFramework.
FOUNDATION_EXPORT double SubFrameworkVersionNumber;

//! Project version string for SubFramework.
FOUNDATION_EXPORT const unsigned char SubFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SubFramework/PublicHeader.h>


